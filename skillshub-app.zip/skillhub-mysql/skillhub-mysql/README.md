# SkillHub – Full-Stack Learning Platform
## Flask + MySQL + Session Auth + Email OTP

---

## Quick Start (5 Steps)

### Step 1 – Create MySQL Database
```bash
mysql -u root -p < database.sql
```

### Step 2 – Install Python Dependencies
```bash
pip install -r requirements.txt
```

### Step 3 – Configure app.py
Edit the top of `app.py` (or set environment variables):

```python
app.config['MYSQL_PASSWORD'] = 'your_mysql_password'
app.config['MAIL_USERNAME']  = 'your_email@gmail.com'
app.config['MAIL_PASSWORD']  = 'your_gmail_app_password'
```

> **Gmail App Password**: Google Account → Security → 2-Step Verification → App Passwords  
> Generate a 16-char password for "Mail" app.

### Step 4 – Run the App
```bash
python app.py
```

### Step 5 – Open in Browser
```
http://127.0.0.1:5000
```

---

## Default Accounts

| Role  | Email                 | Password   |
|-------|-----------------------|------------|
| Admin | admin@skillhub.com    | Admin@123  |
| User  | (sign up yourself)    | —          |

---

## Project Structure

```
skillhub-mysql/
├── app.py                  # Main Flask app (all routes + logic)
├── database.sql            # MySQL schema (run this first)
├── requirements.txt        # Python dependencies
├── .env.example            # Environment config template
├── static/
│   ├── api.js              # Session-based API client
│   ├── theme.js            # UI theme helpers
│   └── utils.js            # Utility functions
└── templates/
    ├── landing.html        # Public landing page
    ├── login.html          # Login + Signup (3 steps) + OTP
    ├── my-learning.html    # User dashboard (/ home)
    ├── courses.html        # Browse & filter courses
    ├── watch.html          # Course viewer + modules + notes
    ├── final-quiz.html     # Final assessment
    ├── feedback.html       # Submit feedback & ratings
    ├── about.html          # About page
    └── admin.html          # Admin dashboard
```

---

## Feature Summary

### Authentication
- Email + password signup (no phone required)
- **OTP email verification** before account activation
- Session-based login (Flask sessions, no JWT)
- Role-based redirect: `user → /home`, `admin → /admin/dashboard`
- Login blocked if email not verified

### User Features
- Browse, search, filter courses (level / language / free/paid)
- Enroll in courses
- Module-based learning with progress tracking
- **Module locking** (sequential unlock via quiz pass)
- Quiz system with randomised questions + option shuffling
- Final assessment → auto certificate on 60%+ score
- Certificate with unique ID (verifiable at `/api/certificates/<code>`)
- Bookmark courses
- Notes per module (auto-saved)
- Submit feedback & ratings
- Learning streak tracker

### Admin Features
- Dashboard analytics (users, enrollments, popular courses, certs)
- Add / Edit / Delete courses
- Add modules with YouTube URLs
- Add quiz questions to course bank
- View all users + enrollment counts
- View all feedback

### Extra Features
- **Recommendation engine** (preference + popularity based)
- **Learning streaks** (daily activity tracking)
- Full error handling (404/500 handlers, try/catch)

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/signup` | Request OTP, store pending signup |
| POST | `/api/auth/verify-otp` | Verify OTP, create account |
| POST | `/api/auth/login` | Login with email/password |
| POST | `/api/auth/logout` | Clear session |
| GET  | `/api/auth/me` | Get current user |
| GET  | `/api/courses/` | List/search courses |
| POST | `/api/courses/` | Create course (admin) |
| PUT  | `/api/courses/<id>` | Update course (admin) |
| DELETE | `/api/courses/<id>` | Delete course (admin) |
| GET  | `/api/enrollments/` | My enrollments |
| POST | `/api/enrollments/enroll` | Enroll in course |
| POST | `/api/enrollments/progress` | Mark module complete |
| GET  | `/api/quiz/questions/<id>` | Get quiz questions |
| POST | `/api/quiz/submit` | Submit module quiz |
| POST | `/api/quiz/final/submit` | Submit final quiz |
| GET  | `/api/certificates/` | My certificates |
| GET  | `/api/certificates/<code>` | Verify certificate |
| GET  | `/api/bookmarks/` | My bookmarks |
| POST | `/api/bookmarks/toggle` | Toggle bookmark |
| GET/POST | `/api/notes/<course>/<module>` | Get/Save note |
| POST | `/api/feedback/` | Submit feedback |
| GET  | `/api/feedback/` | All feedback (admin) |
| GET  | `/api/recommendations/` | Recommended courses |
| GET  | `/api/admin/stats` | Dashboard analytics |
| GET  | `/api/admin/users` | All users |
| GET  | `/api/admin/enrollments` | All enrollments |
| POST | `/api/admin/modules` | Add module |
| POST | `/api/admin/quiz` | Add quiz question |
| GET  | `/api/streak/` | User streak |

---

## Dev Notes

- **OTP not delivered?** Check your terminal – in dev mode, the OTP is printed to console as fallback.
- **MySQL not available?** Change `SQLALCHEMY_DATABASE_URI` to SQLite for local testing.
- The app auto-seeds: 1 admin, 6 sample courses, quiz questions.
- All passwords hashed with Werkzeug's `scrypt` (PBKDF2 fallback).
