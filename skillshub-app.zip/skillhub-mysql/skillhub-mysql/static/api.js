/**
 * SkillHub – Session-Based API Service
 * Works with Flask session cookies (no JWT tokens required)
 */
const API_BASE = 'http://127.0.0.1:5000/api';

const API = {
    getToken()       { return null; },
    setToken(t)      {},
    clearToken()     {},

    async request(method, path, body = null) {
        const headers = { 'Content-Type': 'application/json' };
        const opts    = { method, headers, credentials: 'include' };
        if (body) opts.body = JSON.stringify(body);
        try {
            const res  = await fetch(`${API_BASE}${path}`, opts);
            console.log(res);
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
            return data;
        } catch (err) {
            console.error(`API ${method} ${path}:`, err.message);
            throw err;
        }
    },
    get(path)        { return this.request('GET',    path); },
    post(path, body) { return this.request('POST',   path, body); },
    put(path, body)  { return this.request('PUT',    path, body); },
    delete(path)     { return this.request('DELETE', path); },

    // ─── Auth ──────────────────────────────────────────────
    async signup(name, email, password, phone, preferences) {
        return await this.post('/auth/signup', { name, email, password, preferences });
    },
    async verifyOtp(email, otp) {
        return await this.post('/auth/verify-otp', { email, otp });
    },
    async login(email, password) {
        return await this.post('/auth/login', { email, password });
    },
    async logout() {
        try { await this.post('/auth/logout', {}); } catch (e) {}
        window.location.href = '/login';
    },
    async getMe() {
        try { const d = await this.get('/auth/me'); return d.user; } catch (e) { return null; }
    },

    // ─── Courses ──────────────────────────────────────────
    async getCourses(filters = {}) {
        const params = new URLSearchParams(filters).toString();
        const data = await this.get(`/courses/${params ? '?' + params : ''}`);
        return data.courses;
    },
    async getCourse(id)      { return (await this.get(`/courses/${id}`)).course; },
    async createCourse(d)    { return (await this.post('/courses/', d)).course; },
    async updateCourse(id,d) { return (await this.put(`/courses/${id}`, d)).course; },
    async deleteCourse(id)   { return await this.delete(`/courses/${id}`); },

    // ─── Enrollments ──────────────────────────────────────
    async getEnrollments()           { return (await this.get('/enrollments/')).enrollments; },
    async enroll(courseId)           { return (await this.post('/enrollments/enroll', { courseId })).enrollment; },
    async unenroll(courseId)         { return await this.delete(`/enrollments/unenroll/${courseId}`); },
    async updateProgress(courseId, moduleIndex) {
        return await this.post('/enrollments/progress', { courseId, moduleIndex });
    },

    // ─── Quiz ─────────────────────────────────────────────
    async getQuizQuestions(courseId, module) {
        const param = module === 'final' ? 'final' : String(module);
        return (await this.get(`/quiz/questions/${courseId}?module=${param}`)).questions || [];
    },
    async submitModuleQuiz(courseId, moduleIndex, score, total) {
        return await this.post('/quiz/submit', { courseId, moduleIndex, score, total });
    },
    async submitFinalQuiz(courseId, score, total) {
        return await this.post('/quiz/final/submit', { courseId, score, total });
    },
    async getQuizAttempts(courseId) {
        return (await this.get(`/quiz/attempts/${courseId}`)).attempts;
    },

    // ─── Certificates ─────────────────────────────────────
    async getMyCertificates() { return (await this.get('/certificates/')).certificates; },
    async verifyCertificate(code) { return await this.get(`/certificates/${code}`); },

    // ─── Bookmarks ────────────────────────────────────────
    async getBookmarks()            { return (await this.get('/bookmarks/')).bookmarks; },
    async toggleBookmark(courseId)  { return await this.post('/bookmarks/toggle', { courseId }); },

    // ─── Notes ────────────────────────────────────────────
    async getNote(courseId, modIdx) {
        return (await this.get(`/notes/${courseId}/${modIdx}`)).content || '';
    },
    async saveNote(courseId, modIdx, content) {
        return await this.post(`/notes/${courseId}/${modIdx}`, { content });
    },

    // ─── Feedback ─────────────────────────────────────────
    async submitFeedback(courseId, rating, comment) {
        return await this.post('/feedback/', { courseId, rating, comment });
    },
    async getAllFeedback() { return (await this.get('/feedback/')).feedback; },

    // ─── Recommendations ──────────────────────────────────
    async getRecommendations() { return (await this.get('/recommendations/')).courses; },

    // ─── Admin ────────────────────────────────────────────
    async getAdminStats()       { return await this.get('/admin/stats'); },
    async getAdminUsers()       { return (await this.get('/admin/users')).users; },
    async deleteUser(id)        { return await this.delete(`/admin/users/${id}`); },
    async getAdminEnrollments() { return (await this.get('/admin/enrollments')).enrollments; },
    async addModule(data)       { return await this.post('/admin/modules', data); },
    async addQuizQuestion(data) { return await this.post('/admin/quiz', data); },

    // ─── Streak ───────────────────────────────────────────
    async getStreak() { return await this.get('/streak/'); },

    // ─── Health ───────────────────────────────────────────
    async isOnline() {
        try { await fetch(`${API_BASE}/health`); return true; } catch (e) { return false; }
    }
};
window.API = API;
