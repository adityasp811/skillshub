/**
 * SkillsHub Platform - Shared Utilities
 * Version: 2.0
 * Common functions used across all pages
 */

// ============================================================================
// STORAGE UTILITIES
// ============================================================================

const Storage = {
    /**
     * Safely set item in localStorage
     * @param {string} key - Storage key
     * @param {*} value - Value to store (will be JSON stringified)
     * @returns {boolean} Success status
     */
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('Storage set error:', e);
            this.showError('Unable to save data. Storage might be full.');
            return false;
        }
    },

    /**
     * Safely get item from localStorage
     * @param {string} key - Storage key
     * @param {*} defaultValue - Default value if key doesn't exist
     * @returns {*} Parsed value or default
     */
    get(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item !== null ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.error('Storage get error:', e);
            return defaultValue;
        }
    },

    /**
     * Remove item from localStorage
     * @param {string} key - Storage key
     * @returns {boolean} Success status
     */
    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (e) {
            console.error('Storage remove error:', e);
            return false;
        }
    },

    /**
     * Clear all localStorage
     * @returns {boolean} Success status
     */
    clear() {
        try {
            localStorage.clear();
            return true;
        } catch (e) {
            console.error('Storage clear error:', e);
            return false;
        }
    },

    /**
     * Show error message to user
     */
    showError(message) {
        if (typeof showNotification === 'function') {
            showNotification(message, 'error');
        } else {
            alert(message);
        }
    }
};

// ============================================================================
// VALIDATION UTILITIES
// ============================================================================

const Validator = {
    /**
     * Validate email address
     * @param {string} email - Email to validate
     * @returns {boolean} Is valid
     */
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    /**
     * Validate password strength
     * @param {string} password - Password to validate
     * @returns {string|null} Error message or null if valid
     */
    validatePassword(password) {
        if (!password || password.length < 8) {
            return "Password must be at least 8 characters long";
        }
        
        if (!/[A-Z]/.test(password)) {
            return "Password must contain at least one uppercase letter";
        }
        
        if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
            return "Password must contain at least one special character";
        }
        
        return null; // Valid
    },

    /**
     * Sanitize user input to prevent XSS
     * @param {string} input - Input to sanitize
     * @returns {string} Sanitized input
     */
    sanitize(input) {
        if (typeof input !== 'string') return '';
        const div = document.createElement('div');
        div.textContent = input;
        return div.innerHTML;
    },

    /**
     * Validate URL
     * @param {string} url - URL to validate
     * @returns {boolean} Is valid URL
     */
    isValidURL(url) {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    }
};

// ============================================================================
// AUTH UTILITIES
// ============================================================================

const Auth = {
    /**
     * Get current logged in user
     * @returns {Object|null} User object or null
     */
    getCurrentUser() {
        return Storage.get('skillshub_user');
    },

    /**
     * Check if user is logged in
     * @returns {boolean} Is logged in
     */
    isLoggedIn() {
        const user = this.getCurrentUser();
        return user && user.email && user.loggedIn;
    },

    /**
     * Check if current user is admin
     * @returns {boolean} Is admin
     */
    isAdmin() {
        const user = this.getCurrentUser();
        return user && user.isAdmin === true;
    },

    /**
     * Login user
     * @param {Object} userData - User data
     * @returns {boolean} Success status
     */
    login(userData) {
        const user = {
            ...userData,
            loggedIn: true,
            lastLogin: new Date().toISOString()
        };
        return Storage.set('skillshub_user', user);
    },

    /**
     * Logout current user
     * @returns {boolean} Success status
     */
    logout() {
        return Storage.remove('skillshub_user');
    },

    /**
     * Redirect to login if not authenticated
     */
    requireAuth() {
        if (!this.isLoggedIn()) {
            window.location.href = 'login.html';
        }
    },

    /**
     * Redirect to admin page if not admin
     */
    requireAdmin() {
        if (!this.isAdmin()) {
            window.location.href = 'courses.html';
        }
    }
};

// ============================================================================
// COURSE UTILITIES
// ============================================================================

const CourseManager = {
    /**
     * Get all courses
     * @returns {Array} Array of courses
     */
    getAllCourses() {
        return Storage.get('skillshub_admin_courses', []);
    },

    /**
     * Get course by ID
     * @param {string} courseId - Course ID
     * @returns {Object|null} Course object or null
     */
    getCourseById(courseId) {
        const courses = this.getAllCourses();
        return courses.find(c => String(c.id) === String(courseId)) || null;
    },

    /**
     * Save course
     * @param {Object} course - Course object
     * @returns {boolean} Success status
     */
    saveCourse(course) {
        const courses = this.getAllCourses();
        const existingIndex = courses.findIndex(c => String(c.id) === String(course.id));
        
        if (existingIndex >= 0) {
            courses[existingIndex] = course;
        } else {
            courses.push(course);
        }
        
        return Storage.set('skillshub_admin_courses', courses);
    },

    /**
     * Delete course
     * @param {string} courseId - Course ID
     * @returns {boolean} Success status
     */
    deleteCourse(courseId) {
        const courses = this.getAllCourses();
        const filtered = courses.filter(c => String(c.id) !== String(courseId));
        return Storage.set('skillshub_admin_courses', filtered);
    },

    /**
     * Generate unique course ID
     * @returns {string} Unique ID
     */
    generateId() {
        return 'course_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
};

// ============================================================================
// ENROLLMENT UTILITIES
// ============================================================================

const EnrollmentManager = {
    /**
     * Get storage key for user enrollments
     * @param {string} email - User email
     * @returns {string} Storage key
     */
    getStorageKey(email) {
        return `skillshub_enrolled_${email}`;
    },

    /**
     * Get user's enrolled courses
     * @param {string} email - User email (optional, uses current user if not provided)
     * @returns {Array} Array of enrolled courses
     */
    getEnrolled(email = null) {
        const user = email || Auth.getCurrentUser()?.email;
        if (!user) return [];
        
        const key = this.getStorageKey(user);
        return Storage.get(key, []);
    },

    /**
     * Check if user is enrolled in course
     * @param {string} courseId - Course ID
     * @param {string} email - User email (optional)
     * @returns {boolean} Is enrolled
     */
    isEnrolled(courseId, email = null) {
        const enrolled = this.getEnrolled(email);
        return enrolled.some(c => String(c.id) === String(courseId));
    },

    /**
     * Enroll user in course
     * @param {Object} course - Course object
     * @param {string} email - User email (optional)
     * @returns {boolean} Success status
     */
    enroll(course, email = null) {
        const user = email || Auth.getCurrentUser()?.email;
        if (!user) {
            showNotification('Please login to enroll', 'error');
            return false;
        }

        // Check if already enrolled
        if (this.isEnrolled(course.id, user)) {
            showNotification('Already enrolled in this course', 'info');
            return false;
        }

        const enrollment = {
            id: String(course.id),
            title: course.title,
            instructor: course.instructor,
            category: course.category || 'general',
            language: course.language || 'english',
            type: course.type || 'free',
            price: course.price || 'FREE',
            description: course.description || '',
            url: course.url,
            status: 'Not Started',
            progress: 0,
            enrolledDate: new Date().toISOString(),
            lastActivity: new Date().toISOString(),
            completedDate: null,
            modules: (course.learningPoints || ['Complete Course']).map((point, index) => ({
                id: index,
                name: point,
                completed: false,
                completedAt: null
            }))
        };

        const enrolled = this.getEnrolled(user);
        enrolled.push(enrollment);

        const key = this.getStorageKey(user);
        const success = Storage.set(key, enrolled);

        if (success) {
            showNotification('Successfully enrolled!', 'success');
        }

        return success;
    },

    /**
     * Unenroll from course
     * @param {string} courseId - Course ID
     * @param {string} email - User email (optional)
     * @returns {boolean} Success status
     */
    unenroll(courseId, email = null) {
        const user = email || Auth.getCurrentUser()?.email;
        if (!user) return false;

        const enrolled = this.getEnrolled(user);
        const filtered = enrolled.filter(c => String(c.id) !== String(courseId));

        const key = this.getStorageKey(user);
        return Storage.set(key, filtered);
    },

    /**
     * Update course progress
     * @param {string} courseId - Course ID
     * @param {number} moduleId - Module ID that was completed
     * @param {string} email - User email (optional)
     * @returns {boolean} Success status
     */
    updateProgress(courseId, moduleId, email = null) {
        const user = email || Auth.getCurrentUser()?.email;
        if (!user) return false;

        const enrolled = this.getEnrolled(user);
        const course = enrolled.find(c => String(c.id) === String(courseId));

        if (!course) return false;

        // Mark module as completed
        const module = course.modules.find(m => m.id === moduleId);
        if (module && !module.completed) {
            module.completed = true;
            module.completedAt = new Date().toISOString();
        }

        // Calculate progress
        const completedModules = course.modules.filter(m => m.completed).length;
        const totalModules = course.modules.length;
        course.progress = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;

        // Update status
        if (course.progress === 0) {
            course.status = 'Not Started';
        } else if (course.progress === 100) {
            course.status = 'Completed';
            if (!course.completedDate) {
                course.completedDate = new Date().toISOString();
            }
        } else {
            course.status = 'In Progress';
        }

        // Update last activity
        course.lastActivity = new Date().toISOString();

        const key = this.getStorageKey(user);
        return Storage.set(key, enrolled);
    }
};

// ============================================================================
// UI UTILITIES
// ============================================================================

const UI = {
    /**
     * Show notification
     * @param {string} message - Message to show
     * @param {string} type - Type: success, error, info, warning
     * @param {number} duration - Duration in ms
     */
    showNotification(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            background: ${this.getNotificationColor(type)};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideIn 0.3s ease;
            font-family: 'IBM Plex Mono', monospace;
            max-width: 300px;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, duration);
    },

    /**
     * Get notification color based on type
     */
    getNotificationColor(type) {
        const colors = {
            success: '#00FF88',
            error: '#FF3366',
            info: '#00D9FF',
            warning: '#FFE600'
        };
        return colors[type] || colors.info;
    },

    /**
     * Show loading spinner
     */
    showLoading() {
        if (document.getElementById('globalLoadingSpinner')) return;

        const spinner = document.createElement('div');
        spinner.id = 'globalLoadingSpinner';
        spinner.innerHTML = '<div class="spinner"></div>';
        spinner.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(10, 14, 39, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        `;

        const spinnerStyle = document.createElement('style');
        spinnerStyle.textContent = `
            .spinner {
                width: 50px;
                height: 50px;
                border: 4px solid rgba(0, 217, 255, 0.3);
                border-top: 4px solid #00D9FF;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(spinnerStyle);
        document.body.appendChild(spinner);
    },

    /**
     * Hide loading spinner
     */
    hideLoading() {
        const spinner = document.getElementById('globalLoadingSpinner');
        if (spinner) spinner.remove();
    },

    /**
     * Confirm dialog
     * @param {string} message - Confirmation message
     * @returns {boolean} User confirmation
     */
    confirm(message) {
        return confirm(message);
    }
};

// ============================================================================
// GLOBAL SHORTHAND FUNCTIONS
// ============================================================================

// Make commonly used functions available globally
window.showNotification = UI.showNotification.bind(UI);
window.showLoading = UI.showLoading.bind(UI);
window.hideLoading = UI.hideLoading.bind(UI);

// ============================================================================
// INITIALIZATION
// ============================================================================

// Add notification styles
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Storage,
        Validator,
        Auth,
        CourseManager,
        EnrollmentManager,
        UI
    };
}
