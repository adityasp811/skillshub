// ============================================================================
// STANDALONE THEME MANAGER
// ============================================================================

const ThemeManager = {
    init() {
        // Apply theme early
        let savedTheme = 'dark';
        try {
            savedTheme = localStorage.getItem('skillshub_theme') || 'dark';
        } catch(e) {}
        this.setTheme(savedTheme);

        // Add styles and button when DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.injectUI());
        } else {
            this.injectUI();
        }
    },

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        try {
            localStorage.setItem('skillshub_theme', theme);
        } catch(e) {}
        this.updateButton(theme);
    },

    toggle() {
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        this.setTheme(newTheme);
    },

    updateButton(theme) {
        const btn = document.getElementById('themeToggleBtn');
        if (btn) {
            btn.innerHTML = theme === 'dark' ? '☀️ Light' : '🌙 Dark';
        }
    },

    injectUI() {
        if (document.getElementById('themeToggleBtn')) return;

        // Inject Light Theme CSS
        const style = document.createElement('style');
        style.textContent = `
            [data-theme="light"] {
                --primary: #E61E50;
                --secondary: #0088AA;
                --accent: #E6B800;
                --dark: #F5F7FA;
                --card-bg: #FFFFFF;
                --text: #1A1F3A;
                --text-dim: #6B7280;
                --success: #059669;
            }

            /* Fixes for Light Mode specific UI elements */
            [data-theme="light"] nav {
                background: rgba(255, 255, 255, 0.95) !important;
            }
            [data-theme="light"] .video-container,
            [data-theme="light"] .quiz-modal-content,
            [data-theme="light"] .course-card,
            [data-theme="light"] .stat-card,
            [data-theme="light"] .learning-card,
            [data-theme="light"] .certificate-card,
            [data-theme="light"] .quiz-card,
            [data-theme="light"] .admin-card,
            [data-theme="light"] .login-container {
                border-color: rgba(0,0,0,0.1) !important;
                box-shadow: 0 4px 6px rgba(0,0,0,0.05) !important;
                background: #FFFFFF !important;
            }
            [data-theme="light"] .module-item:hover,
            [data-theme="light"] .quiz-option:hover {
                background: rgba(0,136,170,0.1) !important;
            }

            .theme-toggle-btn {
                position: fixed;
                bottom: 20px;
                right: 20px;
                padding: 0.8rem 1.2rem;
                background: linear-gradient(135deg, var(--primary), var(--secondary));
                color: white;
                border: none;
                border-radius: 50px;
                font-family: 'IBM Plex Mono', monospace;
                font-weight: 600;
                font-size: 0.9rem;
                cursor: pointer;
                z-index: 9999;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            .theme-toggle-btn:hover {
                transform: translateY(-3px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
            }
        `;
        document.head.appendChild(style);

        // Inject Floating Button
        const btn = document.createElement('button');
        btn.id = 'themeToggleBtn';
        btn.className = 'theme-toggle-btn';
        btn.onclick = () => this.toggle();
        document.body.appendChild(btn);
        
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
        this.updateButton(currentTheme);
    }
};

// Initialize theme
ThemeManager.init();
