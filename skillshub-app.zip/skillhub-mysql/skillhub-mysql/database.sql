-- ============================================================
-- SkillHub - MySQL Database Schema
-- Run: mysql -u root -p < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS skillhub_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skillhub_db;

-- ──────────────────────────────────────────────
-- 1. USERS
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL UNIQUE,
    password     VARCHAR(255) NOT NULL,
    role         ENUM('user','admin') NOT NULL DEFAULT 'user',
    is_verified  TINYINT(1) NOT NULL DEFAULT 0,
    preferences  TEXT,                          -- JSON: {topics, lang, level, type}
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Default admin (password: Admin@123)
INSERT IGNORE INTO users (name, email, password, role, is_verified)
VALUES ('Admin', 'admin@skillhub.com',
        'scrypt:32768:8:1$salt$hash_placeholder',   -- replaced at runtime
        'admin', 1);

-- ──────────────────────────────────────────────
-- 2. OTP VERIFICATION
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS otp_verification (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    email       VARCHAR(150) NOT NULL,
    otp         VARCHAR(10)  NOT NULL,
    expiry_time DATETIME     NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_otp_email (email)
);

-- ──────────────────────────────────────────────
-- 3. COURSES
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS courses (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(200) NOT NULL,
    instructor    VARCHAR(150) NOT NULL,
    description   TEXT,
    category      VARCHAR(50)  DEFAULT 'general',
    language      VARCHAR(50)  DEFAULT 'english',
    course_type   ENUM('free','paid') DEFAULT 'free',
    price         VARCHAR(20)  DEFAULT 'FREE',
    thumbnail     VARCHAR(500),
    url           VARCHAR(500),                 -- playlist / intro URL
    what_you_learn TEXT,                        -- JSON array of topics/modules
    is_active     TINYINT(1) DEFAULT 1,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ──────────────────────────────────────────────
-- 4. MODULES
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS modules (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    course_id    INT NOT NULL,
    module_index INT NOT NULL DEFAULT 0,
    title        VARCHAR(300) NOT NULL,
    youtube_url  VARCHAR(500),
    duration     VARCHAR(30),                   -- e.g. "45 min"
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_module_course (course_id)
);

-- ──────────────────────────────────────────────
-- 5. QUIZZES  (questions bank)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS quizzes (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    course_id      INT NOT NULL,
    module_index   INT,                         -- NULL = final assessment
    question       TEXT NOT NULL,
    option_a       VARCHAR(500) NOT NULL,
    option_b       VARCHAR(500) NOT NULL,
    option_c       VARCHAR(500) NOT NULL,
    option_d       VARCHAR(500) NOT NULL,
    correct_option TINYINT NOT NULL,            -- 0=A 1=B 2=C 3=D
    difficulty     ENUM('easy','medium','hard') DEFAULT 'medium',
    explanation    TEXT,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_quiz_course (course_id)
);

-- ──────────────────────────────────────────────
-- 6. ENROLLMENTS
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS enrollments (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    course_id    INT NOT NULL,
    status       ENUM('Not Started','In Progress','Completed') DEFAULT 'Not Started',
    progress     INT DEFAULT 0,
    enrolled_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_enrollment (user_id, course_id),
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ──────────────────────────────────────────────
-- 7. PROGRESS  (per-module completion)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS progress (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    enrollment_id INT NOT NULL,
    module_index  INT NOT NULL,
    module_name   VARCHAR(300) NOT NULL,
    completed     TINYINT(1) DEFAULT 0,
    completed_at  DATETIME,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE,
    INDEX idx_progress_enrollment (enrollment_id)
);

-- ──────────────────────────────────────────────
-- 8. QUIZ ATTEMPTS
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS quiz_attempts (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    course_id    INT NOT NULL,
    module_index INT,                           -- NULL = final quiz
    score        INT NOT NULL,
    total        INT NOT NULL,
    passed       TINYINT(1) DEFAULT 0,
    attempted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ──────────────────────────────────────────────
-- 9. CERTIFICATES
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS certificates (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    course_id  INT NOT NULL,
    cert_code  VARCHAR(60) NOT NULL UNIQUE,
    issued_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ──────────────────────────────────────────────
-- 10. BOOKMARKS
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookmarks (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    course_id  INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_bookmark (user_id, course_id),
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ──────────────────────────────────────────────
-- 11. NOTES  (per-module)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notes (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    course_id    INT NOT NULL,
    module_index INT NOT NULL,
    content      TEXT,
    updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_note (user_id, course_id, module_index),
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ──────────────────────────────────────────────
-- 12. FEEDBACK / RATINGS
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    course_id   INT,                            -- NULL = general platform feedback
    rating      TINYINT,                        -- 1-5
    comment     TEXT,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL
);

-- ──────────────────────────────────────────────
-- 13. LEARNING STREAKS
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS learning_streaks (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL UNIQUE,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    last_activity_date DATE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
