"""
SkillHub – Full-Stack Learning Platform
Flask + MySQL + Session Auth + OTP Email Verification
======================================================
Run:
    pip install -r requirements.txt
    python app.py
"""

import os, json, random, string, smtplib, re
from datetime import datetime, timedelta, date
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from functools import wraps

from flask import (Flask, render_template, request, session,
                   redirect, url_for, jsonify, flash)
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

# ── App & Config ────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = 'skillhub-super-secret-2025'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)

# MySQL
app.config['MYSQL_HOST']     = os.environ.get('MYSQL_HOST', 'localhost')
app.config['MYSQL_USER']     = os.environ.get('MYSQL_USER', 'root')
app.config['MYSQL_PASSWORD'] = os.environ.get('MYSQL_PASSWORD', 'root1234')
app.config['MYSQL_DB']       = os.environ.get('MYSQL_DB',       'skillhub_db')
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

# Email (Gmail SMTP – use an App Password, not your real password)
app.config['MAIL_SERVER']   = os.environ.get('MAIL_SERVER',   'smtp.gmail.com')
app.config['MAIL_PORT']     = int(os.environ.get('MAIL_PORT',   587))
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', 'sanchitapanigrahy23@gmail.com')
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', 'wmkzhwojwqrdjufn')
app.config['MAIL_USE_TLS']  = True

mysql = MySQL(app)

# ── Helpers ─────────────────────────────────────────────────────────

def get_db():
    cur = mysql.connection.cursor()
    return cur

def send_otp_email(to_email: str, otp: str, name: str = '') -> bool:
    """Send OTP via Gmail SMTP. Returns True on success."""
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = '🔐 SkillHub – Your Email Verification OTP'
        msg['From']    = app.config['MAIL_USERNAME']
        msg['To']      = to_email

        html_body = f"""
        <div style="font-family:'IBM Plex Mono',monospace;background:#0A0E27;color:#E8EAED;
                    padding:40px;border-radius:12px;max-width:500px;margin:auto;">
          <h1 style="color:#FF3366;letter-spacing:0.1em;">SkillHub</h1>
          <p>Hello <strong>{name or 'there'}</strong>,</p>
          <p>Your email verification OTP is:</p>
          <div style="font-size:2.5rem;font-weight:700;color:#00D9FF;
                      background:#1A1F3A;padding:20px;border-radius:8px;
                      text-align:center;letter-spacing:0.3em;margin:20px 0;">
            {otp}
          </div>
          <p style="color:#9BA3AF;font-size:0.85rem;">
            This OTP expires in <strong>10 minutes</strong>.<br>
            If you did not sign up, ignore this email.
          </p>
        </div>"""

        msg.attach(MIMEText(html_body, 'html'))

        with smtplib.SMTP(app.config['MAIL_SERVER'], app.config['MAIL_PORT']) as server:
            server.ehlo()
            server.starttls()
            server.login(app.config['MAIL_USERNAME'], app.config['MAIL_PASSWORD'])
            server.sendmail(app.config['MAIL_USERNAME'], to_email, msg.as_string())
        return True
    except Exception as e:
        app.logger.error(f'[EMAIL ERROR] {e}')
        return False

def generate_otp() -> str:
    return ''.join(random.choices(string.digits, k=6))

def generate_cert_code() -> str:
    return 'CERT-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_verified'):
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_verified'):
            return redirect(url_for('login_page'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'error')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated

def update_streak(user_id: int):
    """Update learning streak for a user."""
    cur = get_db()
    today = date.today()
    cur.execute("SELECT * FROM learning_streaks WHERE user_id=%s", (user_id,))
    streak = cur.fetchone()
    if not streak:
        cur.execute("""INSERT INTO learning_streaks (user_id, current_streak, longest_streak, last_activity_date)
                       VALUES (%s, 1, 1, %s)""", (user_id, today))
    else:
        last = streak['last_activity_date']
        if last == today:
            pass  # Already updated today
        elif last == today - timedelta(days=1):
            new_streak = streak['current_streak'] + 1
            longest    = max(new_streak, streak['longest_streak'])
            cur.execute("""UPDATE learning_streaks SET current_streak=%s, longest_streak=%s,
                           last_activity_date=%s WHERE user_id=%s""",
                        (new_streak, longest, today, user_id))
        else:
            # Streak broken
            cur.execute("""UPDATE learning_streaks SET current_streak=1,
                           last_activity_date=%s WHERE user_id=%s""", (today, user_id))
    mysql.connection.commit()

def seed_admin():
    """Ensure a default admin account exists."""
    cur = get_db()
    cur.execute("SELECT id FROM users WHERE email='admin@skillhub.com'")
    if not cur.fetchone():
        pw = generate_password_hash('Admin@123')
        cur.execute("""INSERT INTO users (name, email, password, role, is_verified)
                       VALUES (%s, %s, %s, 'admin', 1)""",
                    ('Admin', 'admin@skillhub.com', pw))
        mysql.connection.commit()
        print('[OK] Admin seeded: admin@skillhub.com / Admin@123')

def seed_courses():
    """Seed sample courses if none exist."""
    cur = get_db()
    cur.execute("SELECT COUNT(*) AS cnt FROM courses")
    if cur.fetchone()['cnt'] > 0:
        return

    sample_courses = [
        {
            'title': 'Python for Beginners',
            'instructor': 'Dr. Arjun Mehta',
            'description': 'Master Python from scratch with hands-on projects. '
                           'Covers syntax, data structures, OOP, file I/O, and more.',
            'category': 'python',
            'language': 'english',
            'course_type': 'free',
            'price': 'FREE',
            'url': 'https://www.youtube.com/playlist?list=PLsyeobzWxl7poL9JTVyndKeCKyVvEnurr',
            'what_you_learn': json.dumps([
                'Python Basics & Syntax',
                'Data Structures & Algorithms',
                'Object-Oriented Programming',
                'File Handling & Exceptions',
                'Libraries & Modules'
            ])
        },
        {
            'title': 'Full Stack Web Development',
            'instructor': 'Priya Sharma',
            'description': 'Build real-world web apps using HTML, CSS, JavaScript, Node.js & React.',
            'category': 'javascript',
            'language': 'english',
            'course_type': 'free',
            'price': 'FREE',
            'url': 'https://www.youtube.com/playlist?list=PLillGF-RfqbYeckUaD1z6nviTp31GLTH8',
            'what_you_learn': json.dumps([
                'HTML5 & CSS3 Fundamentals',
                'JavaScript & ES6+',
                'React Basics',
                'Node.js & Express',
                'Database Integration'
            ])
        },
        {
            'title': 'Java Programming Masterclass',
            'instructor': 'Rahul Gupta',
            'description': 'Comprehensive Java course from basics to advanced enterprise patterns.',
            'category': 'java',
            'language': 'hindi',
            'course_type': 'free',
            'price': 'FREE',
            'url': 'https://www.youtube.com/playlist?list=PLsyeobzWxl7oZ-fxDosB0cQxAk-mkBfvU',
            'what_you_learn': json.dumps([
                'Java Syntax & Variables',
                'OOP Concepts',
                'Collections Framework',
                'Exception Handling',
                'Multithreading'
            ])
        },
        {
            'title': 'Data Structures & Algorithms',
            'instructor': 'Sneha Patel',
            'description': 'Master DSA concepts and crack top tech company interviews.',
            'category': 'dsa',
            'language': 'english',
            'course_type': 'paid',
            'price': '₹999',
            'url': 'https://www.youtube.com/playlist?list=PL9gnSGHSqcnr_DxHsP7AW9ftq0AtAyYqJ',
            'what_you_learn': json.dumps([
                'Arrays & Strings',
                'Linked Lists & Trees',
                'Graphs & BFS/DFS',
                'Dynamic Programming',
                'Sorting & Searching'
            ])
        },
        {
            'title': 'Machine Learning with Python',
            'instructor': 'Dr. Vikram Nair',
            'description': 'Hands-on ML using scikit-learn, pandas, and matplotlib.',
            'category': 'python',
            'language': 'english',
            'course_type': 'paid',
            'price': '₹1499',
            'url': 'https://www.youtube.com/playlist?list=PLeo1K3hjS3uvCeTYTeyfe0-rN5r8zn9rw',
            'what_you_learn': json.dumps([
                'NumPy & Pandas',
                'Data Visualization',
                'Supervised Learning',
                'Unsupervised Learning',
                'Model Evaluation'
            ])
        },
        {
            'title': 'React.js Complete Guide',
            'instructor': 'Ananya Singh',
            'description': 'Build modern web applications with React, Redux, and Hooks.',
            'category': 'javascript',
            'language': 'english',
            'course_type': 'free',
            'price': 'FREE',
            'url': 'https://www.youtube.com/playlist?list=PLillGF-Rfqbb0WS2IqFuJTBZTGEWRpKmj',
            'what_you_learn': json.dumps([
                'React Components & JSX',
                'State & Props',
                'React Hooks',
                'Redux Toolkit',
                'API Integration'
            ])
        },
    ]

    for c in sample_courses:
        cur.execute("""
            INSERT INTO courses (title, instructor, description, category, language,
                                 course_type, price, url, what_you_learn)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (c['title'], c['instructor'], c['description'], c['category'],
              c['language'], c['course_type'], c['price'], c['url'], c['what_you_learn']))

    mysql.connection.commit()
    print(f'[OK] {len(sample_courses)} courses seeded')

    # Seed quiz questions for each course
    cur.execute("SELECT id, title FROM courses")
    courses = cur.fetchall()
    for course in courses:
        _seed_quiz_for_course(cur, course['id'])
    mysql.connection.commit()
    print('[OK] Quiz questions seeded')


def _seed_quiz_for_course(cur, course_id: int):
    """Seed questions for the course."""
    cur.execute("SELECT COUNT(*) AS cnt FROM quizzes WHERE course_id=%s", (course_id,))
    if cur.fetchone()['cnt'] > 0:
        return

    generic_module_qs = [
        ("What does CPU stand for?", "Central Processing Unit", "Computer Personal Unit", "Central Program Unit", "Core Processing Utility", 0, "easy", "CPU stands for Central Processing Unit."),
        ("Which data structure uses LIFO order?", "Queue", "Stack", "Array", "Linked List", 1, "easy", "Stack uses Last-In-First-Out order."),
        ("What is the time complexity of binary search?", "O(n)", "O(n²)", "O(log n)", "O(1)", 2, "medium", "Binary search divides the array each step → O(log n)."),
        ("Which keyword is used to define a function in Python?", "func", "function", "def", "define", 2, "easy", "Python uses 'def' keyword."),
        ("What does HTML stand for?", "Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Logic", "HyperText Machine Language", 0, "easy", "HTML = HyperText Markup Language."),
        ("Which of the following is NOT a JavaScript data type?", "String", "Boolean", "Integer", "Object", 2, "medium", "JavaScript has Number, not Integer specifically."),
        ("What does OOP stand for?", "Object-Oriented Programming", "Oriented Object Processing", "Optional Object Protocol", "Output-Oriented Programming", 0, "easy", "OOP = Object-Oriented Programming."),
        ("Which sorting algorithm has the best average case complexity?", "Bubble Sort", "Quick Sort", "Insertion Sort", "Selection Sort", 1, "hard", "Quick Sort has O(n log n) average."),
        ("What is the default HTTP port?", "443", "8080", "21", "80", 3, "medium", "HTTP default port is 80."),
        ("Which SQL clause is used to filter records?", "ORDER BY", "GROUP BY", "WHERE", "HAVING", 2, "easy", "WHERE filters rows in SQL."),
        ("What does CSS stand for?", "Cascading Style Sheets", "Computer Style Sheets", "Creative Style Sheets", "Colorful Style Sheets", 0, "easy", "CSS stands for Cascading Style Sheets."),
        ("In Python, which built-in function returns the length of a list?", "length()", "len()", "count()", "size()", 1, "easy", "The len() function returns the length of an object."),
        ("What is the main purpose of a database index?", "To store data securely", "To format output", "To speed up data retrieval", "To encrypt data", 2, "medium", "Indexes improve the speed of data retrieval operations."),
        ("Which of the following is a NoSQL database?", "MySQL", "PostgreSQL", "MongoDB", "Oracle", 2, "easy", "MongoDB is a document-oriented NoSQL database."),
        ("What does API stand for?", "Application Programming Interface", "Applied Protocol Interface", "Advanced Programming Integration", "Automated Program Interface", 0, "easy", "API stands for Application Programming Interface."),
        ("Which Git command is used to save changes locally?", "git push", "git commit", "git save", "git upload", 1, "easy", "git commit records changes to the repository."),
        ("What is the correct syntax to output 'Hello World' in Java?", "echo('Hello World');", "System.out.println('Hello World');", "print('Hello World');", "Console.WriteLine('Hello World');", 1, "easy", "Java uses System.out.println to print to the console."),
        ("Which symbol is used for single line comments in JavaScript?", "//", "/*", "#", "<!--", 0, "easy", "JavaScript uses // for single-line comments."),
        ("In relational databases, what uniquely identifies each record in a table?", "Foreign Key", "Primary Key", "Unique Index", "Secondary Key", 1, "easy", "A Primary Key uniquely identifies each row."),
        ("What does JSON stand for?", "JavaScript Object Notation", "Java Syntax Object Network", "JavaScript Output Node", "Java Serialized Object Notation", 0, "easy", "JSON stands for JavaScript Object Notation."),
        ("Which of these is NOT a valid Python data type?", "list", "dictionary", "array", "tuple", 2, "medium", "Python does not have a built-in array type (it uses lists instead)."),
        ("What does MVC stand for in web development?", "Model View Controller", "Multiple View Configuration", "Main Virtual Component", "Model Visual Control", 0, "medium", "MVC is a software architectural pattern."),
        ("Which command creates a new directory in Linux?", "cd", "mkdir", "rmdir", "touch", 1, "easy", "mkdir is used to make a new directory."),
        ("What is the result of 3 + '3' in JavaScript?", "6", "'6'", "'33'", "Error", 2, "medium", "JavaScript coerces the number to a string, resulting in '33'."),
        ("What is the default port for HTTPS?", "80", "443", "8080", "22", 1, "medium", "HTTPS operates on port 443.")
    ]

    for q in generic_module_qs:
        cur.execute("""INSERT INTO quizzes
            (course_id, module_index, question, option_a, option_b, option_c, option_d,
             correct_option, difficulty, explanation)
            VALUES (%s, NULL, %s,%s,%s,%s,%s,%s,%s,%s)""",
            (course_id, q[0], q[1], q[2], q[3], q[4], q[5], q[6], q[7]))


# ── App initialisation callback ──────────────────────────────────────
@app.before_request
def init_db_once():
    """Run once after first request to seed data."""
    if not app.config.get('_seeded'):
        try:
            seed_admin()
            seed_courses()
            app.config['_seeded'] = True
        except Exception as e:
            app.logger.error(f'[SEED ERROR] {e}')


# ════════════════════════════════════════════════════════════════════
#  PAGE ROUTES  (serve HTML templates)
# ════════════════════════════════════════════════════════════════════

@app.route('/')
def index():
    return redirect(url_for('landing'))

@app.route('/landing')
def landing():
    return render_template('landing.html')

@app.route('/login')
def login_page():
    if 'user_id' in session and session.get('is_verified'):
        return redirect(url_for('admin_dashboard') if session.get('role') == 'admin' else url_for('home'))
    return render_template('login.html')

@app.route('/home')
@login_required
def home():
    return render_template('my-learning.html', user=session)

@app.route('/courses')
def courses_page():
    return render_template('courses.html', user=session)

@app.route('/about')
def about_page():
    return render_template('about.html', user=session)

@app.route('/feedback')
@login_required
def feedback_page():
    return render_template('feedback.html', user=session)

@app.route('/watch')
@login_required
def watch_page():
    return render_template('watch.html', user=session)

@app.route('/final-quiz')
@login_required
def final_quiz_page():
    return render_template('final-quiz.html', user=session)

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    return render_template('admin.html', user=session)


# ════════════════════════════════════════════════════════════════════
#  AUTH API ROUTES
# ════════════════════════════════════════════════════════════════════

@app.route('/api/auth/signup', methods=['POST'])
def api_signup():
    data = request.get_json()
    name  = (data.get('name') or '').strip()
    email = (data.get('email') or '').strip().lower()
    pw    = (data.get('password') or '')
    prefs = data.get('preferences', {})

    if not name or not email or not pw:
        return jsonify({'error': 'Name, email, and password are required.'}), 400
    if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w{2,}$', email):
        return jsonify({'error': 'Invalid email address.'}), 400
    if len(pw) < 6:
        return jsonify({'error': 'Password must be at least 6 characters.'}), 400

    cur = get_db()
    cur.execute("SELECT id FROM users WHERE email=%s", (email,))
    if cur.fetchone():
        return jsonify({'error': 'Email already registered.'}), 409

    # Store pending user in session (not DB yet – wait for OTP)
    otp = generate_otp()
    expiry = datetime.utcnow() + timedelta(minutes=10)

    # Remove old OTPs for this email
    cur.execute("DELETE FROM otp_verification WHERE email=%s", (email,))
    cur.execute("INSERT INTO otp_verification (email, otp, expiry_time) VALUES (%s,%s,%s)",
                (email, otp, expiry))
    mysql.connection.commit()

    # Store pending signup info in session
    session['pending_signup'] = {
        'name': name, 'email': email,
        'password': generate_password_hash(pw),
        'preferences': json.dumps(prefs)
    }

    # Send OTP
    sent = send_otp_email(email, otp, name)
    if not sent:
        # Dev fallback – log OTP to console
        print(f'[DEV] OTP for {email}: {otp}')

    return jsonify({'message': 'OTP sent to your email. Please verify.', 'otpSent': True}), 200


@app.route('/api/auth/verify-otp', methods=['POST'])
def api_verify_otp():
    data     = request.get_json()
    email    = (data.get('email') or '').strip().lower()
    user_otp = (data.get('otp') or '').strip()

    cur = get_db()
    cur.execute("""SELECT * FROM otp_verification
                   WHERE email=%s ORDER BY created_at DESC LIMIT 1""", (email,))
    row = cur.fetchone()

    if not row:
        return jsonify({'error': 'No OTP found. Please request a new one.'}), 400
    if datetime.utcnow() > row['expiry_time']:
        return jsonify({'error': 'OTP has expired. Please request a new one.'}), 400
    if row['otp'] != user_otp:
        return jsonify({'error': 'Incorrect OTP.'}), 400

    # OTP valid → create user
    pending = session.get('pending_signup')
    if not pending or pending['email'] != email:
        return jsonify({'error': 'Session expired. Please sign up again.'}), 400

    cur.execute("""INSERT INTO users (name, email, password, role, is_verified, preferences)
                   VALUES (%s,%s,%s,'user',1,%s)""",
                (pending['name'], pending['email'], pending['password'], pending.get('preferences')))
    mysql.connection.commit()

    # Clean up
    cur.execute("DELETE FROM otp_verification WHERE email=%s", (email,))
    mysql.connection.commit()
    session.pop('pending_signup', None)

    # Log in
    cur.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cur.fetchone()
    _set_session(user)

    return jsonify({'message': 'Account verified and created!',
                    'user': _user_dict(user), 'redirect': '/home'}), 201


@app.route('/api/auth/login', methods=['POST'])
def api_login():
    data  = request.get_json()
    email = (data.get('email') or '').strip().lower()
    pw    = (data.get('password') or '')

    if not email or not pw:
        return jsonify({'error': 'Email and password are required.'}), 400

    cur = get_db()
    cur.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cur.fetchone()

    if not user or not check_password_hash(user['password'], pw):
        return jsonify({'error': 'Invalid email or password.'}), 401
    if not user['is_verified']:
        return jsonify({'error': 'Email not verified. Please check your inbox.'}), 403

    _set_session(user)
    redirect_to = '/admin/dashboard' if user['role'] == 'admin' else '/home'
    return jsonify({'message': 'Logged in successfully.',
                    'user': _user_dict(user), 'redirect': redirect_to}), 200


@app.route('/api/auth/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'message': 'Logged out.'}), 200


@app.route('/api/auth/me', methods=['GET'])
def api_me():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("SELECT * FROM users WHERE id=%s", (session['user_id'],))
    user = cur.fetchone()
    if not user:
        session.clear()
        return jsonify({'error': 'User not found.'}), 404
    return jsonify({'user': _user_dict(user)}), 200


@app.route('/api/auth/resend-otp', methods=['POST'])
def api_resend_otp():
    data  = request.get_json()
    email = (data.get('email') or '').strip().lower()
    pending = session.get('pending_signup', {})
    name  = pending.get('name', '') if pending.get('email') == email else ''

    otp    = generate_otp()
    expiry = datetime.utcnow() + timedelta(minutes=10)
    cur    = get_db()
    cur.execute("DELETE FROM otp_verification WHERE email=%s", (email,))
    cur.execute("INSERT INTO otp_verification (email, otp, expiry_time) VALUES (%s,%s,%s)",
                (email, otp, expiry))
    mysql.connection.commit()

    sent = send_otp_email(email, otp, name)
    if not sent:
        print(f'[DEV] New OTP for {email}: {otp}')
    return jsonify({'message': 'New OTP sent.'}), 200


def _set_session(user):
    session.permanent = True
    session['user_id']   = user['id']
    session['user_name'] = user['name']
    session['email']     = user['email']
    session['role']      = user['role']
    session['is_verified'] = user['is_verified']

def _user_dict(user):
    prefs = {}
    if user.get('preferences'):
        try: prefs = json.loads(user['preferences'])
        except Exception: pass
    return {
        'id': user['id'], 'name': user['name'],
        'email': user['email'], 'role': user['role'],
        'isVerified': bool(user['is_verified']),
        'preferences': prefs,
        'createdAt': user['created_at'].isoformat() if user.get('created_at') else ''
    }


# ════════════════════════════════════════════════════════════════════
#  COURSES API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/courses/', methods=['GET'])
def api_get_courses():
    language    = request.args.get('language')
    category    = request.args.get('category')
    course_type = request.args.get('type')
    search      = request.args.get('search', '').strip()

    sql    = "SELECT * FROM courses WHERE is_active=1"
    params = []

    if language:
        sql += " AND language=%s"; params.append(language.lower())
    if category:
        sql += " AND category=%s"; params.append(category.lower())
    if course_type:
        sql += " AND course_type=%s"; params.append(course_type.lower())
    if search:
        sql += " AND (title LIKE %s OR description LIKE %s OR instructor LIKE %s)"
        params += [f'%{search}%', f'%{search}%', f'%{search}%']

    cur = get_db()
    cur.execute(sql, params)
    courses = cur.fetchall()

    # Attach enrollment count for popularity
    result = []
    for c in courses:
        cur.execute("SELECT COUNT(*) AS cnt FROM enrollments WHERE course_id=%s", (c['id'],))
        c['enrollmentCount'] = cur.fetchone()['cnt']
        c['learningPoints']  = json.loads(c['what_you_learn']) if c.get('what_you_learn') else []
        result.append(_course_dict(c))

    return jsonify({'courses': result}), 200


@app.route('/api/courses/<int:course_id>', methods=['GET'])
def api_get_course(course_id):
    cur = get_db()
    cur.execute("SELECT * FROM courses WHERE id=%s AND is_active=1", (course_id,))
    c = cur.fetchone()
    if not c:
        return jsonify({'error': 'Course not found.'}), 404

    cur.execute("SELECT * FROM modules WHERE course_id=%s ORDER BY module_index", (course_id,))
    modules = cur.fetchall()
    cur.execute("SELECT COUNT(*) AS cnt FROM enrollments WHERE course_id=%s", (course_id,))
    c['enrollmentCount'] = cur.fetchone()['cnt']
    c['learningPoints']  = json.loads(c['what_you_learn']) if c.get('what_you_learn') else []
    d = _course_dict(c)
    d['modules'] = [dict(m) for m in modules]
    return jsonify({'course': d}), 200


@app.route('/api/courses/', methods=['POST'])
def api_create_course():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    data = request.get_json()
    if not data.get('title') or not data.get('instructor'):
        return jsonify({'error': 'Title and instructor are required.'}), 400

    learn_pts = json.dumps(data.get('learningPoints', []))
    cur = get_db()
    cur.execute("""INSERT INTO courses (title,instructor,description,category,language,
                   course_type,price,url,what_you_learn)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (data['title'], data['instructor'], data.get('description',''),
                 data.get('category','general').lower(), data.get('language','english').lower(),
                 data.get('type','free').lower(), data.get('price','FREE'),
                 data.get('url',''), learn_pts))
    mysql.connection.commit()
    course_id = cur.lastrowid
    cur.execute("SELECT * FROM courses WHERE id=%s", (course_id,))
    c = cur.fetchone()
    return jsonify({'message': 'Course created.', 'course': _course_dict(c)}), 201


@app.route('/api/courses/<int:course_id>', methods=['PUT'])
def api_update_course(course_id):
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("SELECT * FROM courses WHERE id=%s", (course_id,))
    c = cur.fetchone()
    if not c:
        return jsonify({'error': 'Course not found.'}), 404

    data = request.get_json()
    cur.execute("""UPDATE courses SET title=%s,instructor=%s,description=%s,category=%s,
                   language=%s,course_type=%s,price=%s,url=%s,what_you_learn=%s
                   WHERE id=%s""",
                (data.get('title', c['title']), data.get('instructor', c['instructor']),
                 data.get('description', c['description']), data.get('category', c['category']),
                 data.get('language', c['language']), data.get('type', c['course_type']),
                 data.get('price', c['price']), data.get('url', c['url']),
                 json.dumps(data['learningPoints']) if 'learningPoints' in data else c['what_you_learn'],
                 course_id))
    mysql.connection.commit()
    cur.execute("SELECT * FROM courses WHERE id=%s", (course_id,))
    return jsonify({'message': 'Course updated.', 'course': _course_dict(cur.fetchone())}), 200


@app.route('/api/courses/<int:course_id>', methods=['DELETE'])
def api_delete_course(course_id):
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("UPDATE courses SET is_active=0 WHERE id=%s", (course_id,))
    mysql.connection.commit()
    return jsonify({'message': 'Course deleted.'}), 200


def _course_dict(c):
    lp = c.get('learningPoints') or []
    if not lp and c.get('what_you_learn'):
        try: lp = json.loads(c['what_you_learn'])
        except Exception: lp = []
    return {
        'id': c['id'], 'title': c['title'], 'instructor': c['instructor'],
        'description': c['description'], 'category': c['category'],
        'language': c['language'], 'type': c['course_type'],
        'price': c['price'], 'thumbnail': c.get('thumbnail'),
        'url': c.get('url', ''), 'learningPoints': lp,
        'enrollmentCount': c.get('enrollmentCount', 0),
        'isActive': bool(c['is_active']),
        'createdAt': c['created_at'].isoformat() if c.get('created_at') else ''
    }


# ════════════════════════════════════════════════════════════════════
#  ENROLLMENTS API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/enrollments/', methods=['GET'])
def api_get_enrollments():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("""SELECT e.*, c.title, c.instructor, c.category, c.language,
                          c.course_type, c.price, c.thumbnail, c.url
                   FROM enrollments e
                   JOIN courses c ON e.course_id=c.id
                   WHERE e.user_id=%s""", (session['user_id'],))
    enrollments = cur.fetchall()
    result = []
    for e in enrollments:
        cur.execute("SELECT * FROM progress WHERE enrollment_id=%s ORDER BY module_index",
                    (e['id'],))
        e['modules'] = cur.fetchall()
        result.append(_enrollment_dict(e))
    return jsonify({'enrollments': result}), 200


@app.route('/api/enrollments/enroll', methods=['POST'])
def api_enroll():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    data      = request.get_json()
    course_id = data.get('courseId')
    if not course_id:
        return jsonify({'error': 'courseId is required.'}), 400

    cur = get_db()
    cur.execute("SELECT * FROM courses WHERE id=%s AND is_active=1", (course_id,))
    if not cur.fetchone():
        return jsonify({'error': 'Course not found.'}), 404

    cur.execute("SELECT id FROM enrollments WHERE user_id=%s AND course_id=%s",
                (session['user_id'], course_id))
    if cur.fetchone():
        return jsonify({'error': 'Already enrolled.'}), 409

    cur.execute("""INSERT INTO enrollments (user_id,course_id,status,progress)
                   VALUES (%s,%s,'Not Started',0)""", (session['user_id'], course_id))
    mysql.connection.commit()
    enrollment_id = cur.lastrowid

    # Create progress rows from learningPoints
    cur.execute("SELECT what_you_learn FROM courses WHERE id=%s", (course_id,))
    row = cur.fetchone()
    learn_pts = json.loads(row['what_you_learn']) if row and row['what_you_learn'] else ['Complete Course']
    if not learn_pts:
        learn_pts = ['Complete Course']

    for idx, pt in enumerate(learn_pts):
        cur.execute("""INSERT INTO progress (enrollment_id, module_index, module_name, completed)
                       VALUES (%s,%s,%s,0)""", (enrollment_id, idx, pt))
    mysql.connection.commit()

    cur.execute("""SELECT e.*, c.title, c.instructor, c.category, c.language,
                          c.course_type, c.price, c.thumbnail, c.url
                   FROM enrollments e JOIN courses c ON e.course_id=c.id
                   WHERE e.id=%s""", (enrollment_id,))
    e = cur.fetchone()
    cur.execute("SELECT * FROM progress WHERE enrollment_id=%s ORDER BY module_index",
                (enrollment_id,))
    e['modules'] = cur.fetchall()
    return jsonify({'message': 'Enrolled successfully.', 'enrollment': _enrollment_dict(e)}), 201


@app.route('/api/enrollments/progress', methods=['POST'])
def api_update_progress():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    data         = request.get_json()
    course_id    = data.get('courseId')
    module_index = data.get('moduleIndex')
    if course_id is None or module_index is None:
        return jsonify({'error': 'courseId and moduleIndex are required.'}), 400

    cur = get_db()
    cur.execute("SELECT id FROM enrollments WHERE user_id=%s AND course_id=%s",
                (session['user_id'], course_id))
    enr = cur.fetchone()
    if not enr:
        return jsonify({'error': 'Enrollment not found.'}), 404
    enr_id = enr['id']

    cur.execute("""UPDATE progress SET completed=1, completed_at=%s
                   WHERE enrollment_id=%s AND module_index=%s AND completed=0""",
                (datetime.utcnow(), enr_id, module_index))

    cur.execute("SELECT COUNT(*) AS total FROM progress WHERE enrollment_id=%s", (enr_id,))
    total = cur.fetchone()['total']
    cur.execute("SELECT COUNT(*) AS done FROM progress WHERE enrollment_id=%s AND completed=1", (enr_id,))
    done = cur.fetchone()['done']
    pct  = int((done / total) * 100) if total else 0

    status = 'Not Started' if pct == 0 else ('Completed' if pct == 100 else 'In Progress')
    completed_at = datetime.utcnow() if pct == 100 else None
    cur.execute("""UPDATE enrollments SET progress=%s, status=%s, last_activity=%s,
                   completed_at=COALESCE(completed_at, %s) WHERE id=%s""",
                (pct, status, datetime.utcnow(), completed_at, enr_id))
    mysql.connection.commit()
    update_streak(session['user_id'])
    return jsonify({'message': 'Progress updated.', 'progress': pct, 'status': status}), 200


@app.route('/api/enrollments/unenroll/<int:course_id>', methods=['DELETE'])
def api_unenroll(course_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("SELECT id FROM enrollments WHERE user_id=%s AND course_id=%s",
                (session['user_id'], course_id))
    enr = cur.fetchone()
    if not enr:
        return jsonify({'error': 'Enrollment not found.'}), 404
    cur.execute("DELETE FROM progress WHERE enrollment_id=%s", (enr['id'],))
    cur.execute("DELETE FROM enrollments WHERE id=%s", (enr['id'],))
    mysql.connection.commit()
    return jsonify({'message': 'Unenrolled.'}), 200


def _enrollment_dict(e):
    mods = e.get('modules', [])
    return {
        'id': e['id'], 'courseId': e['course_id'],
        'title': e.get('title',''), 'instructor': e.get('instructor',''),
        'category': e.get('category',''), 'language': e.get('language',''),
        'type': e.get('course_type','free'), 'price': e.get('price','FREE'),
        'thumbnail': e.get('thumbnail'), 'url': e.get('url',''),
        'status': e['status'], 'progress': e['progress'],
        'enrolledDate': e['enrolled_at'].isoformat() if e.get('enrolled_at') else '',
        'lastActivity': e['last_activity'].isoformat() if e.get('last_activity') else '',
        'completedDate': e['completed_at'].isoformat() if e.get('completed_at') else None,
        'modules': [{'id': m['module_index'], 'name': m['module_name'],
                     'completed': bool(m['completed']),
                     'completedAt': m['completed_at'].isoformat() if m.get('completed_at') else None}
                    for m in mods]
    }


# ════════════════════════════════════════════════════════════════════
#  QUIZ API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/quiz/questions/<int:course_id>', methods=['GET'])
def api_quiz_questions(course_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    
    cur = get_db()
    # Fetch all questions for the course regardless of module
    cur.execute("SELECT * FROM quizzes WHERE course_id=%s", (course_id,))
    bank = cur.fetchall()
    
    if not bank:
        return jsonify({'questions': [], 'message': 'No questions found.'}), 200

    # Always sample 10 questions for both module quizzes and final quiz
    sample_size = min(10, len(bank))
    
    selected = random.sample(bank, sample_size)
    out = []
    for q in selected:
        opts    = [q['option_a'], q['option_b'], q['option_c'], q['option_d']]
        correct = opts[q['correct_option']]
        random.shuffle(opts)
        out.append({
            'id': q['id'], 'question': q['question'],
            'options': opts, 'answer': opts.index(correct),
            'difficulty': q['difficulty'], 'explanation': q['explanation']
        })
    return jsonify({'questions': out, 'total': len(out)}), 200


@app.route('/api/quiz/submit', methods=['POST'])
def api_submit_quiz():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    data         = request.get_json()
    course_id    = data.get('courseId')
    module_index = data.get('moduleIndex')
    score        = data.get('score', 0)
    total        = data.get('total', 5)
    passed       = (score / total) >= 0.6 if total else False

    cur = get_db()
    cur.execute("""INSERT INTO quiz_attempts (user_id,course_id,module_index,score,total,passed)
                   VALUES (%s,%s,%s,%s,%s,%s)""",
                (session['user_id'], course_id, module_index, score, total, int(passed)))

    if passed and module_index is not None:
        cur.execute("SELECT id FROM enrollments WHERE user_id=%s AND course_id=%s",
                    (session['user_id'], course_id))
        enr = cur.fetchone()
        if enr:
            cur.execute("""UPDATE progress SET completed=1, completed_at=%s
                           WHERE enrollment_id=%s AND module_index=%s AND completed=0""",
                        (datetime.utcnow(), enr['id'], module_index))
            # Recalculate enrollment progress
            cur.execute("SELECT COUNT(*) AS t FROM progress WHERE enrollment_id=%s", (enr['id'],))
            total_mods = cur.fetchone()['t']
            cur.execute("SELECT COUNT(*) AS d FROM progress WHERE enrollment_id=%s AND completed=1",
                        (enr['id'],))
            done_mods  = cur.fetchone()['d']
            pct        = int((done_mods / total_mods) * 100) if total_mods else 0
            status     = 'Not Started' if pct == 0 else ('Completed' if pct == 100 else 'In Progress')
            cur.execute("""UPDATE enrollments SET progress=%s, status=%s, last_activity=%s
                           WHERE id=%s""", (pct, status, datetime.utcnow(), enr['id']))
        update_streak(session['user_id'])

    mysql.connection.commit()
    pct = round((score / total) * 100, 1) if total else 0
    return jsonify({'passed': passed, 'score': score, 'total': total, 'percentage': pct}), 200


@app.route('/api/quiz/final/submit', methods=['POST'])
def api_submit_final():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    data      = request.get_json()
    course_id = data.get('courseId')
    score     = data.get('score', 0)
    total     = data.get('total', 10)
    passed    = (score / total) >= 0.6 if total else False

    cur = get_db()
    cur.execute("""INSERT INTO quiz_attempts (user_id,course_id,module_index,score,total,passed)
                   VALUES (%s,%s,NULL,%s,%s,%s)""",
                (session['user_id'], course_id, score, total, int(passed)))

    cert_data = None
    if passed:
        cur.execute("SELECT id FROM enrollments WHERE user_id=%s AND course_id=%s",
                    (session['user_id'], course_id))
        enr = cur.fetchone()
        if enr:
            cur.execute("""UPDATE enrollments SET status='Completed', progress=100,
                           completed_at=COALESCE(completed_at,%s), last_activity=%s
                           WHERE id=%s""", (datetime.utcnow(), datetime.utcnow(), enr['id']))

        # Issue certificate if not already done
        cur.execute("SELECT * FROM certificates WHERE user_id=%s AND course_id=%s",
                    (session['user_id'], course_id))
        existing = cur.fetchone()
        if not existing:
            code = generate_cert_code()
            cur.execute("""INSERT INTO certificates (user_id, course_id, cert_code)
                           VALUES (%s,%s,%s)""", (session['user_id'], course_id, code))
            mysql.connection.commit()
            cur.execute("SELECT cert_code, issued_at FROM certificates WHERE user_id=%s AND course_id=%s",
                        (session['user_id'], course_id))
            cert = cur.fetchone()
            cur.execute("SELECT title FROM courses WHERE id=%s", (course_id,))
            cname = cur.fetchone()['title']
            cert_data = {
                'id': cert['cert_code'], 'courseId': course_id,
                'courseName': cname, 'userName': session['user_name'],
                'completionDate': cert['issued_at'].strftime('%d %B %Y'),
                'issueDate': cert['issued_at'].isoformat()
            }
        else:
            cur.execute("SELECT title FROM courses WHERE id=%s", (course_id,))
            cname = cur.fetchone()['title']
            cert_data = {
                'id': existing['cert_code'], 'courseId': course_id,
                'courseName': cname, 'userName': session['user_name'],
                'completionDate': existing['issued_at'].strftime('%d %B %Y')
            }
        update_streak(session['user_id'])

    mysql.connection.commit()
    pct = round((score / total) * 100, 1) if total else 0
    return jsonify({'passed': passed, 'score': score, 'total': total,
                    'percentage': pct, 'certificate': cert_data}), 200


@app.route('/api/quiz/attempts/<int:course_id>', methods=['GET'])
def api_quiz_attempts(course_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("""SELECT * FROM quiz_attempts WHERE user_id=%s AND course_id=%s
                   ORDER BY attempted_at DESC""", (session['user_id'], course_id))
    rows = cur.fetchall()
    out  = [{'id': r['id'], 'courseId': r['course_id'], 'moduleIndex': r['module_index'],
              'score': r['score'], 'total': r['total'],
              'percentage': round((r['score']/r['total'])*100,1) if r['total'] else 0,
              'passed': bool(r['passed']),
              'attemptedAt': r['attempted_at'].isoformat()} for r in rows]
    return jsonify({'attempts': out}), 200


# ════════════════════════════════════════════════════════════════════
#  CERTIFICATES API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/certificates/', methods=['GET'])
def api_my_certs():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("""SELECT cert.cert_code, cert.issued_at, c.title AS course_name, c.id AS course_id
                   FROM certificates cert
                   JOIN courses c ON cert.course_id=c.id
                   WHERE cert.user_id=%s""", (session['user_id'],))
    rows = cur.fetchall()
    out  = [{'id': r['cert_code'], 'courseId': r['course_id'],
              'courseName': r['course_name'], 'userName': session['user_name'],
              'completionDate': r['issued_at'].strftime('%d %B %Y'),
              'issueDate': r['issued_at'].isoformat()} for r in rows]
    return jsonify({'certificates': out}), 200


@app.route('/api/certificates/<cert_code>', methods=['GET'])
def api_verify_cert(cert_code):
    cur = get_db()
    cur.execute("""SELECT cert.*, c.title AS course_name, u.name AS user_name
                   FROM certificates cert
                   JOIN courses c ON cert.course_id=c.id
                   JOIN users u   ON cert.user_id=u.id
                   WHERE cert.cert_code=%s""", (cert_code,))
    cert = cur.fetchone()
    if not cert:
        return jsonify({'valid': False, 'error': 'Certificate not found.'}), 404
    return jsonify({'valid': True, 'certificate': {
        'id': cert['cert_code'], 'courseId': cert['course_id'],
        'courseName': cert['course_name'], 'userName': cert['user_name'],
        'completionDate': cert['issued_at'].strftime('%d %B %Y')
    }}), 200


# ════════════════════════════════════════════════════════════════════
#  BOOKMARKS API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/bookmarks/', methods=['GET'])
def api_get_bookmarks():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("""SELECT b.course_id, b.created_at, c.title, c.instructor, c.category,
                          c.language, c.course_type, c.price, c.thumbnail
                   FROM bookmarks b JOIN courses c ON b.course_id=c.id
                   WHERE b.user_id=%s""", (session['user_id'],))
    rows = cur.fetchall()
    return jsonify({'bookmarks': [
        {'courseId': r['course_id'], 'title': r['title'], 'instructor': r['instructor'],
         'category': r['category'], 'language': r['language'], 'type': r['course_type'],
         'price': r['price'], 'thumbnail': r['thumbnail'],
         'savedAt': r['created_at'].isoformat()} for r in rows
    ]}), 200


@app.route('/api/bookmarks/toggle', methods=['POST'])
def api_toggle_bookmark():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    data      = request.get_json()
    course_id = data.get('courseId')
    cur       = get_db()
    cur.execute("SELECT id FROM bookmarks WHERE user_id=%s AND course_id=%s",
                (session['user_id'], course_id))
    existing = cur.fetchone()
    if existing:
        cur.execute("DELETE FROM bookmarks WHERE user_id=%s AND course_id=%s",
                    (session['user_id'], course_id))
        mysql.connection.commit()
        return jsonify({'bookmarked': False, 'message': 'Bookmark removed.'}), 200
    else:
        cur.execute("INSERT INTO bookmarks (user_id, course_id) VALUES (%s,%s)",
                    (session['user_id'], course_id))
        mysql.connection.commit()
        return jsonify({'bookmarked': True, 'message': 'Bookmarked!'}), 200


# ════════════════════════════════════════════════════════════════════
#  NOTES API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/notes/<int:course_id>/<int:module_index>', methods=['GET'])
def api_get_note(course_id, module_index):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    cur = get_db()
    cur.execute("""SELECT content FROM notes
                   WHERE user_id=%s AND course_id=%s AND module_index=%s""",
                (session['user_id'], course_id, module_index))
    row = cur.fetchone()
    return jsonify({'content': row['content'] if row else ''}), 200


@app.route('/api/notes/<int:course_id>/<int:module_index>', methods=['POST'])
def api_save_note(course_id, module_index):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    content = (request.get_json() or {}).get('content', '')
    cur     = get_db()
    cur.execute("""INSERT INTO notes (user_id, course_id, module_index, content)
                   VALUES (%s,%s,%s,%s)
                   ON DUPLICATE KEY UPDATE content=%s, updated_at=CURRENT_TIMESTAMP""",
                (session['user_id'], course_id, module_index, content, content))
    mysql.connection.commit()
    return jsonify({'message': 'Note saved.'}), 200


# ════════════════════════════════════════════════════════════════════
#  FEEDBACK API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/feedback/', methods=['POST'])
def api_submit_feedback():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated.'}), 401
    data      = request.get_json()
    course_id = data.get('courseId')   # optional
    rating    = data.get('rating')
    comment   = (data.get('comment') or '').strip()
    cur       = get_db()
    cur.execute("""INSERT INTO feedback (user_id, course_id, rating, comment)
                   VALUES (%s,%s,%s,%s)""",
                (session['user_id'], course_id, rating, comment))
    mysql.connection.commit()
    return jsonify({'message': 'Feedback submitted. Thank you!'}), 201


@app.route('/api/feedback/', methods=['GET'])
def api_get_feedback():
    """Admin only – get all feedback."""
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("""SELECT f.*, u.name AS user_name, c.title AS course_title
                   FROM feedback f
                   JOIN users u ON f.user_id=u.id
                   LEFT JOIN courses c ON f.course_id=c.id
                   ORDER BY f.submitted_at DESC""")
    rows = cur.fetchall()
    out  = [{'id': r['id'], 'userName': r['user_name'],
              'courseTitle': r.get('course_title'), 'rating': r['rating'],
              'comment': r['comment'],
              'submittedAt': r['submitted_at'].isoformat()} for r in rows]
    return jsonify({'feedback': out}), 200


# ════════════════════════════════════════════════════════════════════
#  RECOMMENDATIONS API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/recommendations/', methods=['GET'])
def api_recommendations():
    if 'user_id' not in session:
        return jsonify({'courses': []}), 200
    cur = get_db()

    # Get user preferences
    cur.execute("SELECT preferences FROM users WHERE id=%s", (session['user_id'],))
    row   = cur.fetchone()
    prefs = {}
    if row and row['preferences']:
        try: prefs = json.loads(row['preferences'])
        except Exception: pass

    # Get already enrolled course IDs
    cur.execute("SELECT course_id FROM enrollments WHERE user_id=%s", (session['user_id'],))
    enrolled_ids = {r['course_id'] for r in cur.fetchall()}

    # Score courses based on preferences
    cur.execute("SELECT *, (SELECT COUNT(*) FROM enrollments WHERE course_id=courses.id) AS pop "
                "FROM courses WHERE is_active=1")
    all_courses = cur.fetchall()

    def score(c):
        s = 0
        if c['id'] in enrolled_ids:
            return -1  # exclude enrolled
        s += c.get('pop', 0) * 0.5  # popularity boost
        topics = prefs.get('topics', [])
        if c['category'] in topics:
            s += 10
        lang = prefs.get('lang', '')
        if lang in ('both', '') or c['language'] == lang:
            s += 5
        typ = prefs.get('type', '')
        if typ == 'both' or c['course_type'] == typ:
            s += 3
        return s

    ranked = sorted(all_courses, key=score, reverse=True)
    top5   = [_course_dict(c) for c in ranked if c['id'] not in enrolled_ids][:5]
    return jsonify({'courses': top5}), 200


# ════════════════════════════════════════════════════════════════════
#  ADMIN API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/admin/stats', methods=['GET'])
def api_admin_stats():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("SELECT COUNT(*) AS cnt FROM users WHERE role='user'")
    total_users = cur.fetchone()['cnt']
    cur.execute("SELECT COUNT(*) AS cnt FROM courses WHERE is_active=1")
    total_courses = cur.fetchone()['cnt']
    cur.execute("SELECT COUNT(*) AS cnt FROM enrollments")
    total_enrollments = cur.fetchone()['cnt']
    cur.execute("SELECT COUNT(*) AS cnt FROM certificates")
    total_certs = cur.fetchone()['cnt']
    cur.execute("SELECT COUNT(*) AS cnt FROM enrollments WHERE status='Completed'")
    completed = cur.fetchone()['cnt']

    # Most popular courses
    cur.execute("""SELECT c.title, COUNT(e.id) AS cnt
                   FROM courses c LEFT JOIN enrollments e ON c.id=e.course_id
                   WHERE c.is_active=1
                   GROUP BY c.id ORDER BY cnt DESC LIMIT 5""")
    popular = [{'title': r['title'], 'enrollments': r['cnt']} for r in cur.fetchall()]

    return jsonify({
        'totalUsers': total_users, 'totalCourses': total_courses,
        'totalEnrollments': total_enrollments, 'totalCertificates': total_certs,
        'completedCourses': completed, 'popularCourses': popular
    }), 200


@app.route('/api/admin/users', methods=['GET'])
def api_admin_users():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC")
    users = cur.fetchall()
    out   = []
    for u in users:
        cur.execute("SELECT COUNT(*) AS cnt FROM enrollments WHERE user_id=%s", (u['id'],))
        enr_count = cur.fetchone()['cnt']
        d = _user_dict(u)
        d['enrollmentCount'] = enr_count
        out.append(d)
    return jsonify({'users': out}), 200


@app.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
def api_admin_delete_user(user_id):
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("SELECT role FROM users WHERE id=%s", (user_id,))
    u = cur.fetchone()
    if not u:
        return jsonify({'error': 'User not found.'}), 404
    if u['role'] == 'admin':
        return jsonify({'error': 'Cannot delete admin users.'}), 400
    cur.execute("DELETE FROM users WHERE id=%s", (user_id,))
    mysql.connection.commit()
    return jsonify({'message': 'User deleted.'}), 200


@app.route('/api/admin/enrollments', methods=['GET'])
def api_admin_enrollments():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    cur = get_db()
    cur.execute("""SELECT e.*, u.name AS user_name, u.email AS user_email, c.title AS course_title
                   FROM enrollments e
                   JOIN users u   ON e.user_id=u.id
                   JOIN courses c ON e.course_id=c.id
                   ORDER BY e.enrolled_at DESC""")
    rows = cur.fetchall()
    out  = [{'id': r['id'], 'userName': r['user_name'], 'userEmail': r['user_email'],
              'courseTitle': r['course_title'], 'status': r['status'],
              'progress': r['progress'],
              'enrolledDate': r['enrolled_at'].isoformat()} for r in rows]
    return jsonify({'enrollments': out}), 200


@app.route('/api/admin/modules', methods=['POST'])
def api_admin_add_module():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    data      = request.get_json()
    course_id = data.get('courseId')
    title     = (data.get('title') or '').strip()
    yt_url    = (data.get('youtubeUrl') or '').strip()
    duration  = (data.get('duration') or '').strip()

    if not course_id or not title:
        return jsonify({'error': 'courseId and title are required.'}), 400

    cur = get_db()
    cur.execute("SELECT COALESCE(MAX(module_index)+1, 0) AS nxt FROM modules WHERE course_id=%s",
                (course_id,))
    nxt = cur.fetchone()['nxt']
    cur.execute("""INSERT INTO modules (course_id, module_index, title, youtube_url, duration)
                   VALUES (%s,%s,%s,%s,%s)""",
                (course_id, nxt, title, yt_url, duration))
    mysql.connection.commit()
    return jsonify({'message': 'Module added.', 'moduleIndex': nxt}), 201


@app.route('/api/admin/quiz', methods=['POST'])
def api_admin_add_quiz():
    if session.get('role') != 'admin':
        return jsonify({'error': 'Admin access required.'}), 403
    data = request.get_json()
    cur  = get_db()
    cur.execute("""INSERT INTO quizzes (course_id, module_index, question,
                   option_a, option_b, option_c, option_d, correct_option, difficulty, explanation)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (data['courseId'], data.get('moduleIndex'),
                 data['question'], data['optionA'], data['optionB'],
                 data['optionC'], data['optionD'],
                 data['correctOption'], data.get('difficulty','medium'),
                 data.get('explanation','')))
    mysql.connection.commit()
    return jsonify({'message': 'Question added.'}), 201


# ════════════════════════════════════════════════════════════════════
#  STREAK API
# ════════════════════════════════════════════════════════════════════

@app.route('/api/streak/', methods=['GET'])
def api_streak():
    if 'user_id' not in session:
        return jsonify({'currentStreak': 0, 'longestStreak': 0}), 200
    cur = get_db()
    cur.execute("SELECT * FROM learning_streaks WHERE user_id=%s", (session['user_id'],))
    row = cur.fetchone()
    if not row:
        return jsonify({'currentStreak': 0, 'longestStreak': 0}), 200
    return jsonify({'currentStreak': row['current_streak'],
                    'longestStreak': row['longest_streak'],
                    'lastActivityDate': row['last_activity_date'].isoformat()
                    if row.get('last_activity_date') else None}), 200


# ════════════════════════════════════════════════════════════════════
#  ERROR HANDLERS
# ════════════════════════════════════════════════════════════════════

@app.errorhandler(404)
def not_found(e):
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Endpoint not found.'}), 404
    return redirect(url_for('landing'))

@app.errorhandler(500)
def server_error(e):
    app.logger.error(f'500 error: {e}')
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Internal server error.'}), 500
    return redirect(url_for('landing'))


# ════════════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    print("""
╔══════════════════════════════════════════╗
║     SkillHub – Learning Platform         ║
║  Flask + MySQL + Session Auth + OTP      ║
╚══════════════════════════════════════════╝

Setup checklist before running:
  1. mysql -u root -p < database.sql
  2. Edit app.config MYSQL_PASSWORD / MAIL_USERNAME / MAIL_PASSWORD
  3. pip install -r requirements.txt
  4. python app.py

Default admin → admin@skillhub.com / Admin@123
""")
    app.run(debug=True, host='127.0.0.1', port=5000)
